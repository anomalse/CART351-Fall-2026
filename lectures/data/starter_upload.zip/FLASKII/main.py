
from flask import Flask,render_template,request,url_for,redirect
app = Flask(__name__)
@app.route('/')

def index():
   return render_template("index.html",
                           user={"username":"sabine"},
                           passedDictionary={
                                            "fav_color":"fuscia", 
                                             "fav_veg":"cauliflower",
                                             "fav_fruit":"kiwi",
                                             "fav_animal":"toucan"
                                             },
                            imgPath = "../static/images/pineapple_2.jpg"
                                        
                        )
@app.route("/pineappleA")
def pineAppleA():

    return render_template("pineappleChild.html",
                           dataPassedA = "child A!" )

@app.route("/pineappleB")
def pineAppleB():

    # return render_template("pineappleChild_B.html",
    #                        passedImg = "../static/images/pineapple_2.jpg" )
    return render_template("pineAppleChild_B.html",
                           passedImg = "pineapple_2.jpg" ) 

@app.route("/inputPlant")
def addPlantData():
    return render_template("addPlantData.html") 

# @app.route("/thank_you")
# def thank_you():
#     app.logger.info(request.args)
#     #return render_template("thankyou.html") 
#     return render_template("thankyou.html",owner_name = request.args["a_name"]) 

@app.route("/thank_you")
def thank_you():
    app.logger.info(request.args)
  
    if('a_name' in request.args):
        owner_name = request.args["a_name"] 
        app.logger.info("first run to redirect")
         #url is not clean
        #return render_template("thankyou.html",owner_name = request.args["a_name"]) 
        
        # issue we lose the parameters! - but url is clean :)
        return redirect(url_for("thank_you")) 
    #part of the reloading process... we redirect - then headers rewritten and reload the template
    else:
        app.logger.info("reloaded and redirected")
        return render_template("thankyou.html") 

@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"),404

@app.route("/register")
def register():
     return render_template("register.html")

@app.route("/reg_thank_you",methods = ['POST', 'GET'])
def reg_thank_you():
     app.logger.info(request.method)
     app.logger.info(request.form)
     app.logger.info(request.form["f_name"])
     app.logger.info(request.form["l_name"])
     fName = request.form["f_name"]
     lName = request.form["l_name"]
     return render_template("thankyou_reg.html", fName = fName, lName=lName)
     #return render_template("thankyou_reg.html")

app.run(debug=True)